const API_BASE = window.location.origin + '/api';

const urlInput = document.getElementById('url-input');
const fetchBtn = document.getElementById('fetch-btn');
const fetchLoader = document.getElementById('fetch-loader');
const btnText = fetchBtn.querySelector('.btn-text');
const resultArea = document.getElementById('result-area');
const errorMessage = document.getElementById('error-message');
const qualitySelect = document.getElementById('quality-select');

const mediaThumb = document.getElementById('media-thumb');
const mediaTitle = document.getElementById('media-title');
const mediaUploader = document.getElementById('media-uploader');
const mediaDuration = document.getElementById('media-duration');

const downloadVideoBtn = document.getElementById('download-video');
const downloadAudioBtn = document.getElementById('download-audio');

const historySection = document.getElementById('history-section');
const historyList = document.getElementById('history-list');
const clearHistoryBtn = document.getElementById('clear-history');

let currentUrl = '';

// Theme Handling
const themeDots = document.querySelectorAll('.theme-dot');
themeDots.forEach(dot => {
    dot.addEventListener('click', () => {
        const color = dot.getAttribute('data-color');
        document.documentElement.style.setProperty('--primary', color);
        document.documentElement.style.setProperty('--primary-glow', `${color}66`);
        themeDots.forEach(d => d.classList.remove('active'));
        dot.classList.add('active');
        localStorage.setItem('as3g-theme', color);
    });
});

// Load Theme Preference
const savedTheme = localStorage.getItem('as3g-theme');
if (savedTheme) {
    document.documentElement.style.setProperty('--primary', savedTheme);
    document.documentElement.style.setProperty('--primary-glow', `${savedTheme}66`);
    const activeDot = document.querySelector(`.theme-dot[data-color="${savedTheme}"]`);
    if (activeDot) {
        themeDots.forEach(d => d.classList.remove('active'));
        activeDot.classList.add('active');
    }
}

// History Handling
function saveToHistory(info, url) {
    let history = JSON.parse(localStorage.getItem('as3g-history') || '[]');
    // Avoid duplicates
    history = history.filter(item => item.url !== url);
    history.unshift({
        url,
        title: info.title,
        thumbnail: info.thumbnail,
        uploader: info.uploader,
        timestamp: Date.now()
    });
    // Keep only last 10
    history = history.slice(0, 10);
    localStorage.setItem('as3g-history', JSON.stringify(history));
    renderHistory();
}

function renderHistory() {
    const history = JSON.parse(localStorage.getItem('as3g-history') || '[]');
    if (history.length === 0) {
        historySection.classList.add('hidden');
        return;
    }

    historySection.classList.remove('hidden');
    historyList.innerHTML = '';
    
    history.forEach(item => {
        const div = document.createElement('div');
        div.className = 'history-item';
        div.innerHTML = `
            <img src="${item.thumbnail}" alt="thumb">
            <div class="history-item-info">
                <h4>${item.title}</h4>
                <p>${item.uploader || 'Unknown'}</p>
            </div>
        `;
        div.addEventListener('click', () => {
            urlInput.value = item.url;
            fetchBtn.click();
        });
        historyList.appendChild(div);
    });
}

clearHistoryBtn.addEventListener('click', () => {
    localStorage.removeItem('as3g-history');
    renderHistory();
});

// Initial render
renderHistory();

fetchBtn.addEventListener('click', async () => {
    const url = urlInput.value.trim();
    if (!url) return;

    errorMessage.classList.add('hidden');
    resultArea.classList.add('hidden');
    setLoading(true);

    try {
        const response = await fetch(`${API_BASE}/info?url=${encodeURIComponent(url)}`);
        const data = await response.json();

        if (data.error) {
            showError(data.error);
        } else {
            showResult(data, url);
            saveToHistory(data, url);
        }
    } catch (err) {
        showError('Failed to connect to the server.');
    } finally {
        setLoading(false);
    }
});

function setLoading(isLoading) {
    if (isLoading) {
        fetchLoader.style.display = 'block';
        btnText.style.opacity = '0';
        fetchBtn.disabled = true;
    } else {
        fetchLoader.style.display = 'none';
        btnText.style.opacity = '1';
        fetchBtn.disabled = false;
    }
}

function showError(msg) {
    errorMessage.textContent = msg;
    errorMessage.classList.remove('hidden');
}

function showResult(info, url) {
    currentUrl = url;
    mediaThumb.src = info.thumbnail;
    mediaTitle.textContent = info.title;
    mediaUploader.textContent = info.uploader || 'Unknown Artist';
    mediaDuration.textContent = info.duration || '0:00';
    
    // Populate Resolutions
    qualitySelect.innerHTML = '<option value="max">Best Quality</option>';
    if (info.resolutions) {
        info.resolutions.forEach(res => {
            const option = document.createElement('option');
            option.value = `${res}p`;
            option.textContent = `${res}p`;
            qualitySelect.appendChild(option);
        });
    }
    
    resultArea.classList.remove('hidden');
}

downloadVideoBtn.addEventListener('click', () => {
    const quality = qualitySelect.value;
    const downloadUrl = `${API_BASE}/download?url=${encodeURIComponent(currentUrl)}&type=video&quality=${quality}`;
    window.location.href = downloadUrl;
});

downloadAudioBtn.addEventListener('click', () => {
    const downloadUrl = `${API_BASE}/download?url=${encodeURIComponent(currentUrl)}&format=audio`;
    window.location.href = downloadUrl;
});
